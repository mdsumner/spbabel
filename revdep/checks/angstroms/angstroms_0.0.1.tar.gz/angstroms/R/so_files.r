
#' Find and return data base of files
#'
#' @param files the files
#'
#' @return data frame of files
#' @noRd
#' @importFrom rancid NetCDF
# so_files <- function(files = NULL) {
#   if (is.null(files)) {
#    files <- list.files("/rdsi/PRIVATE/data_local/acecrc.org.au/ROMS/s_corney/cpolar", 
#                       full.names = TRUE, pattern = "ocean_his")
#   }
#   ## gives a data base of the metadata contents of a file
#    ## currently incomplete, so we only summarize the first file
#    db <- rancid::NetCDF(files[1])
#  db
# }
# 
# 

