library(testthat)
library(angstroms)

test_check("angstroms")
