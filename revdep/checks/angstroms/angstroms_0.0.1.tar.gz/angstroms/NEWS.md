# angstroms 0.0.1

* added documentation for croproms and ROMS URL, thanks to CRAN feedback

* romsdata defaults to transpose

* updates and checks


# angstroms 0.0.0.9000

* use spbabel::sp not spFromTable

* Added ncraster function to read arbitrary slices

* Added romshcoords function to flesh out "h" by "Cs_r"

* Added a `NEWS.md` file to track changes to the package.



