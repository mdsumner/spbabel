library(testthat)
library(spdplyr)

test_check("spdplyr")
