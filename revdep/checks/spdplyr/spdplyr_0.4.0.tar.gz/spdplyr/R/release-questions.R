release_questions <- function()
  c("Have you single-quoted package and other non-English names in the DESCRIPTION and TITLE?\nhttps://cran.r-project.org/doc/manuals/r-release/R-exts.html#The-DESCRIPTION-file", 
    "Have you manually inspected your rendered vignettes?")